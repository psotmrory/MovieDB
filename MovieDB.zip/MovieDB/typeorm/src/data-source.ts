import "reflect-metadata"
import { DataSource } from "typeorm"
import { Movie } from "./entity/Movie"
import { Director } from "./entity/Director"
import { Studio } from "./entity/Studio"
import { Genre } from "./entity/Genre"


export const AppDataSource = new DataSource({
    type: "postgres",
    host: "34.116.143.43",
    port: 5432,
    username: "postgres",
    password: "g6$4cV42g#EK!Pk",
    database: "MovieDB",
    synchronize: false,
    logging: false,
    entities: [Director, Movie, Genre, Studio], 
    migrations: ['src/migration/**/*.ts'],
    subscribers: [],
})
