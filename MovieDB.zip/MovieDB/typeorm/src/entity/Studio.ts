import { Entity, PrimaryGeneratedColumn, Column } from "typeorm";

@Entity()
export class Studio {

    @PrimaryGeneratedColumn()
    id: number;

    @Column()
    studioName: string;

    @Column()
    country: string;

}
