import { AppDataSource } from "./data-source";
import { Movie } from "./entity/Movie";
import { Director } from "./entity/Director";
import { Studio } from "./entity/Studio";
import { Genre } from "./entity/Genre";

async function seedDatabase() {
    try {
        await AppDataSource.initialize();

        console.log("Seeding the database...");

        // Добавление режиссеров
        const directors = [
            { firstName: "Quentin", lastName: "Tarantino", age: 58, nationality: "American" },
            { firstName: "Christopher", lastName: "Nolan", age: 51, nationality: "British" },
            { firstName: "Steven", lastName: "Spielberg", age: 75, nationality: "American" },
            { firstName: "Martin", lastName: "Scorsese", age: 79, nationality: "American" },
            { firstName: "Alfred", lastName: "Hitchcock", age: 1899, nationality: "British" },
            { firstName: "Hayao", lastName: "Miyazaki", age: 81, nationality: "Japanese" },
            { firstName: "Stanley", lastName: "Kubrick", age: 1928, nationality: "American" },
            { firstName: "James", lastName: "Cameron", age: 67, nationality: "Canadian" },
            { firstName: "Ridley", lastName: "Scott", age: 84, nationality: "British" },
            { firstName: "David", lastName: "Fincher", age: 59, nationality: "American" },

        ];
        const savedDirectors = await Promise.all(directors.map(directorData => {
            const director = new Director();
            Object.assign(director, directorData);
            return AppDataSource.manager.save(director);
        }));

        console.log("Directors added:", savedDirectors);

   
        const genres = [
            { genreName: "Action" },
            { genreName: "Drama" },
            { genreName: "Comedy" },
            { genreName: "Horror" },
            { genreName: "Science Fiction" },
            { genreName: "Fantasy" },
            { genreName: "Thriller" },
            { genreName: "Animation" },
            { genreName: "Adventure" },
            { genreName: "Crime" },
          
        ];
        const savedGenres = await Promise.all(genres.map(genreData => {
            const genre = new Genre();
            Object.assign(genre, genreData);
            return AppDataSource.manager.save(genre);
        }));

        console.log("Genres added:", savedGenres);

     
        const studios = [
            { studioName: "Miramax Films", country: "USA" },
            { studioName: "Paramount Pictures", country: "USA" },
            { studioName: "Universal Pictures", country: "USA" },
            { studioName: "20th Century Studios", country: "USA" },
            { studioName: "Warner Bros. Pictures", country: "USA" },
            { studioName: "Walt Disney Pictures", country: "USA" },
            { studioName: "Studio Ghibli", country: "Japan" },
            { studioName: "Columbia Pictures", country: "USA" },
            { studioName: "DreamWorks Pictures", country: "USA" },
            { studioName: "New Line Cinema", country: "USA" },

        
        ];
        const savedStudios = await Promise.all(studios.map(studioData => {
            const studio = new Studio();
            Object.assign(studio, studioData);
            return AppDataSource.manager.save(studio);
        }));

        console.log("Studios added:", savedStudios);

      
        const movies = [
            { rating: 8, movieName: "Pulp Fiction", releaseYear: 1994, genre_id: 1, studio_id: 1, director_id: 1 },
            { rating: 9, movieName: "Inglourious Basterds", releaseYear: 2009, genre_id: 1, studio_id: 1, director_id: 1 },
            { rating: 10, movieName: "The Dark Knight", releaseYear: 2008, genre_id: 1, studio_id: 2, director_id: 2 },
            { rating: 10, movieName: "Interstellar", releaseYear: 2014, genre_id: 5, studio_id: 2, director_id: 2 },
            { rating: 8, movieName: "Saving Private Ryan", releaseYear: 1998, genre_id: 1, studio_id: 3, director_id: 3 },
            { rating: 7, movieName: "Jurassic Park", releaseYear: 1993, genre_id: 5, studio_id: 3, director_id: 3 },
            { rating: 9, movieName: "Goodfellas", releaseYear: 1990, genre_id: 10, studio_id: 1, director_id: 4 },
            { rating: 8, movieName: "The Shining", releaseYear: 1980, genre_id: 4, studio_id: 4, director_id: 7 },
            { rating: 10, movieName: "The Shawshank Redemption", releaseYear: 1994, genre_id: 2, studio_id: 5, director_id: 1 },
            { rating: 8, movieName: "Fight Club", releaseYear: 1999, genre_id: 1, studio_id: 6, director_id: 10 },

        ];
        const savedMovies = await Promise.all(movies.map(movieData => {
            const movie = new Movie();
            Object.assign(movie, movieData);
            return AppDataSource.manager.save(movie);
        }));

        console.log("Movies added:", savedMovies);

        console.log("Database seeding completed successfully.");
    } catch (error) {
        console.error("Error during database seeding:", error);
    }
}

seedDatabase();
